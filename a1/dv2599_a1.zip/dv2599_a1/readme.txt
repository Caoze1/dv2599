How to run the winequality code:

1. Install python [https://www.python.org/downloads/]
2. Install jupyter notebook [https://jupyter.org/install] 
3. Install required packages, seen in the Initialize step in the notebook book.ipynb. (imblearn, sklearn and pandas)
4. Run the code one section at a time from top to bottom, or "Run All" to run all sections in order.

